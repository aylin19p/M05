﻿
namespace P05_CryptoMiningSystem
{
    public class Program
    {
        static void Main()
        {
           
        }
    }
}